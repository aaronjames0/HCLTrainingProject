package com.hcl.userservice.models;

import lombok.Getter;
import lombok.Setter;
import org.bson.Document;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.Objects;

@Table(name="user")
@Entity
@Setter
@Getter
@NotNull
@NotEmpty
public class User {

    @Id
    private String name;
    private String password;
    private String email;
    private boolean admin;
    private String destination;

    //Empty Constructor
    public User() {
    }

    //Constructor to be used for registration
    public User(String name, String password, String email, boolean admin, String destination) {
        this.name = name;
        this.password = password;
        this.email = email;
        this.admin = admin;
        this.destination = destination;
    }

    //Constructor for results from db fetches.
    public User(Document document) {
        this.name = (document.containsKey("name")) ? document.getString("name") : null;
        this.password = (document.containsKey("password")) ? document.getString("password") : null;
        this.email = (document.containsKey("email")) ? document.getString("email") : null;
        this.admin = (document.containsKey("admin")) ? document.getBoolean("admin") : false;
        this.destination = (document.containsKey("destination")) ? document.getString("destination") : null;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        User user = (User) o;
        return name.equals(user.name) && password.equals(user.password) && email.equals(user.email);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, password, email);
    }

    @Override
    public String toString() {
        return String.format("Name: %s, Password: %s, Email: %s, Admin: %b, Destination: %s", name, password, email, admin, destination);
    }
}
