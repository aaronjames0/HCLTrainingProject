package com.hcl.userservice.dto;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Id;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Setter
@Getter
public class UserDto {

    @Id
    private String name;
    private String password;
    private String email;
    private boolean admin;
    private String destination;
}
