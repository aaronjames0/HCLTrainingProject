package com.hcl.userservice.dto;

import lombok.Data;

import javax.persistence.Id;

@Data
public class UserDto {

    @Id
    private String name;
    private String password;
    private String email;
    private boolean admin;
    private String destination;
}
