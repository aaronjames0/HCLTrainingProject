package com.example.Recommendmicroservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RecommendMicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RecommendMicroserviceApplication.class, args);
	}

}
