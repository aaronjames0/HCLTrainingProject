package com.travel_microservices.hclteamprojectgroupb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HclteamprojectgroupbApplicationTests {

	@Test
	void contextLoads() {
	}

}
