package com.composite.compositeservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompositeserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
