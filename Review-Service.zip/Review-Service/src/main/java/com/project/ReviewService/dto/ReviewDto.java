package com.project.ReviewService.dto;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Id;

@Getter
@Setter
public class ReviewDto {

    @Id
    private long reviewId;
    private long destId;
    private String author;
    private String subject;
    private String content;

}
