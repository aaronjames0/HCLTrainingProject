package com.project.ReviewService.controller;

import com.project.ReviewService.model.Review;
import com.project.ReviewService.review.ReviewRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/reviews")
public class ReviewController {

    @Autowired
    private ReviewRepository repo;

    @GetMapping("/all")
    public List<Review> getAllReviews() {
        return repo.findAll();
    }

    @GetMapping("/author/{author}")
    public List<Review> getReviewsByAuthor(@PathVariable String author) {
        return repo.findByAuthor(author);
    }

    @GetMapping("/destination/{destId}")
    public List<Review> getReviewsByDestination(@PathVariable long destId) {
        return repo.findByDestId(destId);
    }

    @GetMapping("/{reviewId}")
    public Review getReviewById(@PathVariable long reviewId) {
        return repo.findByReviewId(reviewId);
    }

    @PostMapping("/insert")
    public void insertReview(@RequestBody Review review) {
        repo.insertReview(review.getDestId(), review.getAuthor(), review.getSubject(), review.getContent());
    }

    @PutMapping("/update")
    public void updateReview(@RequestBody Review review) {
        repo.updateReview(review.getReviewId(), review.getDestId(), review.getAuthor(), review.getSubject(), review.getContent());
    }

    @DeleteMapping("/delete/{reviewId}")
    public void deleteReview(@PathVariable long reviewId) { repo.deleteReviewByReviewId(reviewId); }

    @DeleteMapping("/delete/author/{author}")
    public void deleteReviewsByAuthor(@PathVariable String author) { repo.deleteReviewsByAuthor(author); }
}
