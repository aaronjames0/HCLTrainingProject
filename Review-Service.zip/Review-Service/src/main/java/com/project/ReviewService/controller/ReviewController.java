package com.project.ReviewService.controller;

import com.project.ReviewService.dto.ReviewDto;
import com.project.ReviewService.mapper.ReviewMapper;
import com.project.ReviewService.model.Review;
import com.project.ReviewService.review.ReviewRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/reviews")
public class ReviewController {

    @Autowired
    private ReviewMapper mapper;

    @Autowired
    private ReviewRepository repo;

    @GetMapping("/all")
    public ResponseEntity<List<ReviewDto>> getAllReviews() {
        return new ResponseEntity<>(mapper.modelsToDto(repo.findAll()), HttpStatus.OK);
    }

    @GetMapping("/author/{author}")
    public ResponseEntity<List<ReviewDto>> getReviewsByAuthor(@PathVariable String author) {
        return new ResponseEntity<>(mapper.modelsToDto(repo.findByAuthor(author)), HttpStatus.OK);
    }

    @GetMapping("/destination/{destId}")
    public ResponseEntity<List<ReviewDto>> getReviewsByDestination(@PathVariable long destId) {
        return new ResponseEntity<>(mapper.modelsToDto(repo.findByDestId(destId)), HttpStatus.OK);
    }

    @GetMapping("/{reviewId}")
    public ResponseEntity<ReviewDto> getReviewById(@PathVariable long reviewId) {
        return new ResponseEntity<>(mapper.modelToDto(repo.findByReviewId(reviewId)), HttpStatus.OK);
    }

    @PostMapping("/insert")
    public ResponseEntity<Void> insertReview(@RequestBody Review review) {
        repo.insertReview(review.getDestId(), review.getAuthor(), review.getSubject(), review.getContent());
        return new ResponseEntity<>(HttpStatus.CREATED);
    }

    @PutMapping("/update")
    public ResponseEntity<Void> updateReview(@RequestBody Review review) {
        repo.updateReview(review.getReviewId(), review.getDestId(), review.getAuthor(), review.getSubject(), review.getContent());
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @DeleteMapping("/delete/{reviewId}")
    public ResponseEntity<Void> deleteReview(@PathVariable long reviewId) {
        repo.deleteReviewByReviewId(reviewId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
    @DeleteMapping("/delete/author/{author}")
    public ResponseEntity<Void> deleteReviewsByAuthor(@PathVariable String author) {
        repo.deleteReviewsByAuthor(author);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
