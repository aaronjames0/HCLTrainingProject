package com.destination.destinationservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DestinationserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
