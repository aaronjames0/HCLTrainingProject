package com.destination.destinationservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DestinationApp {

	public static void main(String[] args) {
		SpringApplication.run(DestinationApp.class, args);
	}

}